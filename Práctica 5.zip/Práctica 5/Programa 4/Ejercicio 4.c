#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
  
  char fecha[15], mess[20];
  int i;
  int tamanio,dia,mes,anio;
  char *apunt= strtok(fecha, "/");
  
  
  
  printf("   Introduzca la fecha en formato 00/00/0000:   ");
  gets (fecha);
  
  tamanio= strlen(fecha);
  apunt= strtok(fecha, "/");

     if(apunt != NULL){
                printf("\n       dia --> %s\n\n",apunt);
                dia= atoi(apunt);
                apunt = strtok(NULL,"/");
                }
     
     if(apunt != NULL){
                printf("\       mes --> %s\n\n",apunt);
                mes= atoi(apunt);
                apunt = strtok(NULL,"/");
               }
     if(apunt != NULL){
                printf("\       anio --> %s\n\n",apunt);
                anio= atoi(apunt);
                apunt = strtok(NULL,"/");
               }
               
  switch(mes){
              case 1:
                   strcpy (mess,"de enero del");
                   break;
              case 2:
                    strcpy (mess,"de febrero del");
                   break;
              case 3:
                    strcpy (mess,"de marzo del");
                   break;
              case 4:
                    strcpy (mess,"de abril del");
                   break;
              case 5:
                    strcpy (mess,"de mayo del");
                   break;
              case 6:
                    strcpy (mess,"de junio del");
                   break;
              case 7:
                    strcpy (mess,"de julio del");
                   break;
              case 8:
                    strcpy (mess,"de agosto del");
                   break;
              case 9:
                    strcpy (mess,"de septiembre del");
                   break;
              case 10:
                    strcpy (mess,"de octubre del");
                   break;
              case 11:
                    strcpy (mess,"de noviembre del");
                   break;
              case 12:
                    strcpy (mess,"de diciembre del");
                   break;
              }
  printf("   Fecha en formato: 'Dia del mes del anio':  %d %s 20%d",dia,mess,anio);
  printf("\n\n\n\n\n");
  system("PAUSE");	
  return 0;
}
