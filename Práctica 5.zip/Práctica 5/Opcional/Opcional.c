#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char palabra[20];
    int i, j, M;
    int palindromo = 1;
    printf("Programa que detecta un palindromo bajo esta condicion:\n\
    1.- No debe haber espacios");
    printf("\n\nEscribe una frase: \n");
    gets(palabra);
    int count=strlen(palabra);
    for (M=count;M>=0;M--){
        palabra[M]=toupper(palabra[M]);
        }
    j=strlen(palabra)-1;
    for(i=0; i<strlen(palabra)/2; i++, j--) {
        
        if (*(palabra+i)!=*(palabra+j)) {
            palindromo = 0;
            break;
        }
    }
    if (palindromo)
        printf("\nEs un palindrimo.\n");
    else
        printf("\nNo es un palindrimo.\n");
        printf("\n");
        system("PAUSE");
    return (0);
}
