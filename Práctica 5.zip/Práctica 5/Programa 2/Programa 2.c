#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	char invertir[20], linea [20];
	int tamanio, i,r;
	char *t;
	
printf("Digite la palabra a invertir: \n");
	gets(linea);
	tamanio=strlen(linea);
	
	r=0;
	for(i=tamanio;i>=0;i--){
		invertir[r]=linea[i];
		t=invertir;
		printf("%c", linea[i]);
		r++;
	}
	
	
	
	return 0;
}
