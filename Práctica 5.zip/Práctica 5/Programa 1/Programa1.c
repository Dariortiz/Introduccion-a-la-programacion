#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	
char string[50];
gets (string);

char *tok =strtok(string, " ");

while (tok !=NULL){
	printf("%s \n", tok);
	tok=strtok(NULL, " ");
	
}
system("pause");
		return 0;
}
